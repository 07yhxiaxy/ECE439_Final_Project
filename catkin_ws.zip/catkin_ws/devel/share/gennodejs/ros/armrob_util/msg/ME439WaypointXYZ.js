// Auto-generated. Do not edit!

// (in-package armrob_util.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ME439WaypointXYZ {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.xyz = null;
    }
    else {
      if (initObj.hasOwnProperty('xyz')) {
        this.xyz = initObj.xyz
      }
      else {
        this.xyz = new Array(3).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ME439WaypointXYZ
    // Check that the constant length array field [xyz] has the right length
    if (obj.xyz.length !== 3) {
      throw new Error('Unable to serialize array field xyz - length must be 3')
    }
    // Serialize message field [xyz]
    bufferOffset = _arraySerializer.float32(obj.xyz, buffer, bufferOffset, 3);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ME439WaypointXYZ
    let len;
    let data = new ME439WaypointXYZ(null);
    // Deserialize message field [xyz]
    data.xyz = _arrayDeserializer.float32(buffer, bufferOffset, 3)
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'armrob_util/ME439WaypointXYZ';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a14e115b7c54d12a98ac59b965cebc44';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32[3] xyz
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ME439WaypointXYZ(null);
    if (msg.xyz !== undefined) {
      resolved.xyz = msg.xyz;
    }
    else {
      resolved.xyz = new Array(3).fill(0)
    }

    return resolved;
    }
};

module.exports = ME439WaypointXYZ;
